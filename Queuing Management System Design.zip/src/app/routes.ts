import { createBrowserRouter } from 'react-router';
import { Root } from './Root';
import { LoginPage } from './pages/LoginPage';
import { FrontdeskPage } from './pages/FrontdeskPage';
import { CounterPage } from './pages/CounterPage';
import { AdminPage } from './pages/AdminPage';
import { SuperAdminPage } from './pages/SuperAdminPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ExecutivePage } from './pages/ExecutivePage';
import { DisplayPage } from './pages/DisplayPage';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, element: null }, // Will redirect to login
      { path: 'frontdesk', element: null },
      { path: 'counter', element: null },
      { path: 'admin', element: null },
      { path: 'super-admin', element: null },
      { path: 'analytics', element: null },
      { path: 'executive', element: null },
      { path: 'display', element: null },
    ],
  },
]);
