// Type definitions for Queuing Management System

export type ServiceCode = 'E' | 'C' | 'R' | 'G' | 'I' | 'S' | 'L';

export type TicketStatus = 'waiting' | 'serving' | 'completed' | 'transferred' | 'on-hold';

export type UserRole = 'counter' | 'admin' | 'super-admin' | 'frontdesk';

export interface Service {
  id: string;
  name: string;
  code: ServiceCode;
  counters: number[];
  description?: string;
}

export interface Counter {
  id: number;
  name: string;
  serviceIds: string[];
  isActive: boolean;
}

export interface Client {
  applicationNumber?: string;
  name: string;
  profession: string;
  sex: 'Male' | 'Female';
}

export interface Ticket {
  id: string;
  ticketNumber: string;
  serviceId: string;
  serviceCode: ServiceCode;
  sequence: number;
  client: Client;
  quantity: number;
  status: TicketStatus;
  createdAt: Date;
  calledAt?: Date;
  completedAt?: Date;
  counterId?: number;
  assignedUserId?: string;
  transferHistory?: TransferRecord[];
}

export interface TransferRecord {
  fromService?: string;
  toService?: string;
  fromCounter?: number;
  toCounter?: number;
  reason: string;
  transferredAt: Date;
  transferredBy: string;
}

export interface Transaction {
  id: string;
  ticketId: string;
  ticketNumber: string;
  serviceId: string;
  counterId: number;
  userId: string;
  client: Client;
  startTime: Date;
  endTime?: Date;
  waitingTime: number; // in seconds
  serviceTime?: number; // in seconds
  status: 'in-progress' | 'completed';
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  assignedCounters: number[];
  isActive: boolean;
}

export interface VoiceAnnouncement {
  ticketNumber: string;
  counterNumber: number;
  timestamp: Date;
}

export interface SystemSettings {
  dailyResetTime: string;
  waitingTimeThreshold: number; // in minutes
  voiceEnabled: boolean;
  autoCallNext: boolean;
}
