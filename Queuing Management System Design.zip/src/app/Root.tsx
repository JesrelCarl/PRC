import { useState, useEffect } from 'react';
import { useNavigate, useLocation, Outlet } from 'react-router';
import { LoginPage } from './pages/LoginPage';
import { FrontdeskPage } from './pages/FrontdeskPage';
import { CounterPage } from './pages/CounterPage';
import { AdminPage } from './pages/AdminPage';
import { SuperAdminPage } from './pages/SuperAdminPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ExecutivePage } from './pages/ExecutivePage';
import { DisplayPage } from './pages/DisplayPage';
import { USERS } from './store';

export function Root() {
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  const currentUser = currentUserId ? USERS.find(u => u.id === currentUserId) : null;

  useEffect(() => {
    // Redirect to login if not authenticated and not on display page
    if (!currentUser && location.pathname !== '/' && location.pathname !== '/display') {
      navigate('/');
    }
    // Redirect authenticated users from root to their default page
    if (currentUser && location.pathname === '/') {
      switch (currentUser.role) {
        case 'frontdesk':
          navigate('/frontdesk');
          break;
        case 'counter':
          navigate('/counter');
          break;
        case 'admin':
          navigate('/admin');
          break;
        case 'super-admin':
          navigate('/super-admin');
          break;
      }
    }
  }, [currentUser, location.pathname, navigate]);

  const handleLogin = (userId: string) => {
    setCurrentUserId(userId);
  };

  const handleLogout = () => {
    setCurrentUserId(null);
    navigate('/');
  };

  // Display page is public
  if (location.pathname === '/display') {
    return <DisplayPage />;
  }

  // Login page
  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Render appropriate page based on route
  switch (location.pathname) {
    case '/frontdesk':
      return <FrontdeskPage currentUser={currentUser} onLogout={handleLogout} />;
    case '/counter':
      return <CounterPage currentUser={currentUser} onLogout={handleLogout} />;
    case '/admin':
      return <AdminPage currentUser={currentUser} onLogout={handleLogout} />;
    case '/super-admin':
      return <SuperAdminPage currentUser={currentUser} onLogout={handleLogout} />;
    case '/analytics':
      return <AnalyticsPage currentUser={currentUser} onLogout={handleLogout} />;
    case '/executive':
      return <ExecutivePage currentUser={currentUser} onLogout={handleLogout} />;
    default:
      return null;
  }
}
