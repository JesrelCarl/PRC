import { useState } from 'react';
import { Plus, Trash2, Printer, CheckCircle } from 'lucide-react';
import { Layout } from '../components/Layout';
import { PrintTicket } from '../components/PrintTicket';
import { SERVICES, queueStore } from '../store';
import { Ticket } from '../types';

interface FrontdeskPageProps {
  currentUser: any;
  onLogout: () => void;
}

interface ServiceSelection {
  serviceId: string;
  quantity: number;
}

export function FrontdeskPage({ currentUser, onLogout }: FrontdeskPageProps) {
  const [applicationNumber, setApplicationNumber] = useState('');
  const [clientName, setClientName] = useState('');
  const [profession, setProfession] = useState('');
  const [sex, setSex] = useState<'Male' | 'Female'>('Male');
  const [selectedServices, setSelectedServices] = useState<ServiceSelection[]>([]);
  const [generatedTickets, setGeneratedTickets] = useState<Ticket[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);

  const addService = () => {
    setSelectedServices([...selectedServices, { serviceId: '', quantity: 1 }]);
  };

  const removeService = (index: number) => {
    setSelectedServices(selectedServices.filter((_, i) => i !== index));
  };

  const updateService = (index: number, field: 'serviceId' | 'quantity', value: string | number) => {
    const updated = [...selectedServices];
    updated[index] = { ...updated[index], [field]: value };
    setSelectedServices(updated);
  };

  const handleGenerateTickets = (e: React.FormEvent) => {
    e.preventDefault();

    if (!clientName || selectedServices.length === 0) {
      return;
    }

    const client = {
      applicationNumber: applicationNumber || undefined,
      name: clientName,
      profession,
      sex
    };

    const tickets: Ticket[] = [];
    selectedServices.forEach(selection => {
      if (selection.serviceId) {
        const ticket = queueStore.generateTicket(selection.serviceId, client, selection.quantity);
        tickets.push(ticket);
      }
    });

    setGeneratedTickets(tickets);
    setShowSuccess(true);

    // Reset form
    setTimeout(() => {
      setApplicationNumber('');
      setClientName('');
      setProfession('');
      setSex('Male');
      setSelectedServices([]);
      setShowSuccess(false);
    }, 3000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleNewClient = () => {
    setGeneratedTickets([]);
    setShowSuccess(false);
  };

  return (
    <Layout userRole={currentUser.role} userName={currentUser.name} onLogout={onLogout}>
      <PrintTicket tickets={generatedTickets} />
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">Frontdesk / PACD</h1>
          <p className="text-gray-600">Generate tickets for walk-in clients</p>
        </div>

        {showSuccess && generatedTickets.length > 0 ? (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Tickets Generated!</h2>
              <p className="text-gray-600 mb-6">Please provide the following tickets to the client:</p>

              <div className="space-y-4 mb-6">
                {generatedTickets.map(ticket => {
                  const service = SERVICES.find(s => s.id === ticket.serviceId);
                  return (
                    <div key={ticket.id} className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6">
                      <div className="text-5xl font-bold text-blue-600 mb-2">{ticket.ticketNumber}</div>
                      <div className="text-gray-700 font-medium">{service?.name}</div>
                      <div className="text-sm text-gray-600 mt-2">
                        Counters: {service?.counters.join(', ')}
                      </div>
                      {ticket.quantity > 1 && (
                        <div className="text-sm text-gray-600 mt-1">
                          Quantity: {ticket.quantity}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handlePrint}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  <Printer className="w-5 h-5" />
                  Print Tickets
                </button>
                <button
                  onClick={handleNewClient}
                  className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  New Client
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-4xl">
            <form onSubmit={handleGenerateTickets} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Client Information</h2>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Application Number <span className="text-gray-400">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    value={applicationNumber}
                    onChange={(e) => setApplicationNumber(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter application number"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Client Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter client name"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Profession
                  </label>
                  <input
                    type="text"
                    value={profession}
                    onChange={(e) => setProfession(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter profession"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Sex
                  </label>
                  <select
                    value={sex}
                    onChange={(e) => setSex(e.target.value as 'Male' | 'Female')}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Services Requested</h3>
                  <button
                    type="button"
                    onClick={addService}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    Add Service
                  </button>
                </div>

                {selectedServices.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No services added. Click "Add Service" to begin.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {selectedServices.map((selection, index) => (
                      <div key={index} className="flex gap-3 items-end">
                        <div className="flex-1">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Service
                          </label>
                          <select
                            value={selection.serviceId}
                            onChange={(e) => updateService(index, 'serviceId', e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            required
                          >
                            <option value="">Select service...</option>
                            {SERVICES.map(service => (
                              <option key={service.id} value={service.id}>
                                {service.name} ({service.code})
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="w-32">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Quantity
                          </label>
                          <input
                            type="number"
                            min="1"
                            value={selection.quantity}
                            onChange={(e) => updateService(index, 'quantity', parseInt(e.target.value) || 1)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => removeService(index)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-3 mt-6 pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  disabled={!clientName || selectedServices.length === 0}
                  className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Generate Tickets
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </Layout>
  );
}