import { useState, useEffect } from 'react';
import { queueStore, SERVICES } from '../store';
import { Ticket } from '../types';

export function DisplayPage() {
  const [currentlyServing, setCurrentlyServing] = useState<Ticket[]>([]);
  const [recentlyCalled, setRecentlyCalled] = useState<Ticket[]>([]);
  const [queueCounts, setQueueCounts] = useState<Record<string, number>>({});
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const updateDisplay = () => {
      setCurrentlyServing(queueStore.getCurrentlyServing());
      setRecentlyCalled(queueStore.getRecentlyCalled(5));
      
      const counts: Record<string, number> = {};
      SERVICES.forEach(service => {
        const waiting = queueStore.getTickets({ serviceId: service.id, status: 'waiting' });
        counts[service.id] = waiting.length;
      });
      setQueueCounts(counts);
    };

    updateDisplay();
    const interval = setInterval(updateDisplay, 2000);
    
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      clearInterval(interval);
      clearInterval(timeInterval);
    };
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white p-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-5xl font-bold mb-2">Queue Management System</h1>
        <div className="text-2xl text-blue-200">{formatDate(currentTime)}</div>
        <div className="text-4xl font-semibold text-blue-100 mt-2">{formatTime(currentTime)}</div>
      </div>

      {/* Currently Serving */}
      <div className="mb-8">
        <h2 className="text-3xl font-semibold mb-6 text-center">NOW SERVING</h2>
        <div className="grid grid-cols-3 gap-6">
          {currentlyServing.length === 0 ? (
            <div className="col-span-3 text-center py-12 bg-white/10 rounded-2xl backdrop-blur-sm">
              <p className="text-2xl text-blue-200">No tickets currently being served</p>
            </div>
          ) : (
            currentlyServing.map(ticket => (
              <div
                key={ticket.id}
                className="bg-white text-gray-900 rounded-2xl p-8 shadow-2xl transform hover:scale-105 transition-transform"
              >
                <div className="text-center">
                  <div className="text-7xl font-bold text-blue-600 mb-4">
                    {ticket.ticketNumber}
                  </div>
                  <div className="text-3xl font-semibold mb-2">
                    Counter {ticket.counterId}
                  </div>
                  <div className="text-xl text-gray-600">
                    {SERVICES.find(s => s.id === ticket.serviceId)?.name}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Recently Called */}
        <div className="col-span-2 bg-white/10 backdrop-blur-sm rounded-2xl p-6">
          <h2 className="text-2xl font-semibold mb-4">Recently Called</h2>
          <div className="space-y-3">
            {recentlyCalled.length === 0 ? (
              <div className="text-center py-8 text-blue-200">
                No recent calls
              </div>
            ) : (
              recentlyCalled.map((ticket, index) => (
                <div
                  key={ticket.id}
                  className="flex items-center justify-between bg-white/20 rounded-lg p-4"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                      <span className="text-xl font-semibold">{index + 1}</span>
                    </div>
                    <div>
                      <div className="text-2xl font-semibold">{ticket.ticketNumber}</div>
                      <div className="text-blue-200">
                        {SERVICES.find(s => s.id === ticket.serviceId)?.name}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-semibold">Counter {ticket.counterId}</div>
                    <div className="text-sm text-blue-200">
                      {ticket.calledAt ? new Date(ticket.calledAt).toLocaleTimeString() : ''}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Queue Status */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
          <h2 className="text-2xl font-semibold mb-4">Queue Status</h2>
          <div className="space-y-3">
            {SERVICES.map(service => (
              <div
                key={service.id}
                className="bg-white/20 rounded-lg p-4"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xl font-semibold">{service.code}</div>
                    <div className="text-sm text-blue-200">{service.name}</div>
                  </div>
                  <div className="text-4xl font-bold">
                    {queueCounts[service.id] || 0}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Announcements */}
      <div className="mt-8 bg-yellow-500/20 backdrop-blur-sm rounded-2xl p-6 border-2 border-yellow-400/50">
        <h2 className="text-2xl font-semibold mb-3 text-yellow-300">Announcements</h2>
        <p className="text-xl text-yellow-100">
          Please proceed to your assigned counter when your number is called. Thank you for your patience.
        </p>
      </div>
    </div>
  );
}
