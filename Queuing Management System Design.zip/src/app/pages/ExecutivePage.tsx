import { useState, useEffect } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Clock, Award, AlertTriangle, Activity } from 'lucide-react';
import { Layout } from '../components/Layout';
import { KPICard } from '../components/KPICard';
import { queueStore, SERVICES } from '../store';

interface ExecutivePageProps {
  currentUser: any;
  onLogout: () => void;
}

export function ExecutivePage({ currentUser, onLogout }: ExecutivePageProps) {
  const [stats, setStats] = useState(queueStore.getStatistics());
  const [tickets, setTickets] = useState(queueStore.getTickets());

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(queueStore.getStatistics());
      setTickets(queueStore.getTickets());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    return `${mins} min`;
  };

  // Find longest waiting ticket
  const waitingTickets = tickets.filter(t => t.status === 'waiting');
  const longestWaiting = waitingTickets.reduce((longest, ticket) => {
    const waitTime = Date.now() - ticket.createdAt.getTime();
    const longestWaitTime = longest ? Date.now() - longest.createdAt.getTime() : 0;
    return waitTime > longestWaitTime ? ticket : longest;
  }, null as any);

  // Most requested service
  const serviceCounts = SERVICES.map(service => ({
    name: service.name,
    code: service.code,
    count: tickets.filter(t => t.serviceId === service.id).length
  })).sort((a, b) => b.count - a.count);

  const mostRequested = serviceCounts[0];

  // Peak hour data (mock for demo)
  const peakHourData = [
    { hour: '8 AM', tickets: 5 },
    { hour: '9 AM', tickets: 12 },
    { hour: '10 AM', tickets: 18 },
    { hour: '11 AM', tickets: 22 },
    { hour: '12 PM', tickets: 15 },
    { hour: '1 PM', tickets: 10 },
    { hour: '2 PM', tickets: 16 },
    { hour: '3 PM', tickets: 20 },
    { hour: '4 PM', tickets: 14 },
    { hour: '5 PM', tickets: 8 }
  ];

  // Service comparison data
  const serviceComparisonData = SERVICES.map(service => {
    const serviceTickets = tickets.filter(t => t.serviceId === service.id);
    const completed = serviceTickets.filter(t => t.status === 'completed').length;
    const waiting = serviceTickets.filter(t => t.status === 'waiting').length;
    
    return {
      name: service.code,
      completed,
      waiting,
      total: serviceTickets.length
    };
  });

  return (
    <Layout userRole={currentUser.role} userName={currentUser.name} onLogout={onLogout}>
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">Executive Dashboard</h1>
          <p className="text-gray-600">High-level overview and system monitoring</p>
        </div>

        {/* Top KPIs - Large Cards */}
        <div className="grid grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-2xl shadow-lg p-8">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-blue-100 mb-2">Total In Queue</p>
                <p className="text-5xl font-bold">{stats.inQueue}</p>
              </div>
              <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                <Users className="w-10 h-10" />
              </div>
            </div>
            <p className="text-blue-100">Across all services</p>
          </div>

          <div className="bg-gradient-to-br from-green-500 to-green-600 text-white rounded-2xl shadow-lg p-8">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-green-100 mb-2">Served Today</p>
                <p className="text-5xl font-bold">{stats.servedToday}</p>
              </div>
              <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                <Award className="w-10 h-10" />
              </div>
            </div>
            <p className="text-green-100">Completed transactions</p>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-2xl shadow-lg p-8">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-purple-100 mb-2">Avg Wait Time</p>
                <p className="text-5xl font-bold">{formatTime(stats.avgWaitingTime)}</p>
              </div>
              <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                <Clock className="w-10 h-10" />
              </div>
            </div>
            <p className="text-purple-100">Overall average</p>
          </div>
        </div>

        {/* Secondary KPIs */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <KPICard
            title="Currently Serving"
            value={stats.serving}
            icon={Activity}
            color="green"
          />
          <KPICard
            title="Avg Service Time"
            value={formatTime(stats.avgServiceTime)}
            icon={TrendingUp}
            color="blue"
          />
          <KPICard
            title="Most Requested"
            value={mostRequested?.code || 'N/A'}
            icon={Award}
            color="yellow"
          />
          <KPICard
            title="Longest Wait"
            value={longestWaiting ? formatTime(Math.floor((Date.now() - longestWaiting.createdAt.getTime()) / 1000)) : '0 min'}
            icon={AlertTriangle}
            color="red"
          />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          {/* Peak Hour Chart */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Peak Hour Analysis</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={peakHourData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="tickets" 
                  stroke="#3B82F6" 
                  strokeWidth={3}
                  name="Tickets Generated"
                  dot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Service Comparison */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Service Performance</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={serviceComparisonData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="completed" fill="#10B981" name="Completed" />
                <Bar dataKey="waiting" fill="#F59E0B" name="Waiting" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Service Overview Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Service Overview</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Service</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Code</th>
                  <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Waiting</th>
                  <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Serving</th>
                  <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Completed</th>
                  <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Total</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Counters</th>
                </tr>
              </thead>
              <tbody>
                {SERVICES.map(service => {
                  const serviceTickets = tickets.filter(t => t.serviceId === service.id);
                  const waiting = serviceTickets.filter(t => t.status === 'waiting').length;
                  const serving = serviceTickets.filter(t => t.status === 'serving').length;
                  const completed = serviceTickets.filter(t => t.status === 'completed').length;
                  
                  return (
                    <tr key={service.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 text-sm text-gray-900">{service.name}</td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2 py-1 rounded bg-blue-100 text-blue-800 text-xs font-semibold">
                          {service.code}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded bg-yellow-100 text-yellow-800 text-sm font-medium">
                          {waiting}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded bg-green-100 text-green-800 text-sm font-medium">
                          {serving}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded bg-gray-100 text-gray-800 text-sm font-medium">
                          {completed}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center text-sm font-semibold text-gray-900">
                        {serviceTickets.length}
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600">
                        {service.counters.join(', ')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Layout>
  );
}
