import { useState } from 'react';
import { Settings, Database, Volume2, Clock, Save } from 'lucide-react';
import { Layout } from '../components/Layout';
import { SERVICES } from '../store';

interface SuperAdminPageProps {
  currentUser: any;
  onLogout: () => void;
}

export function SuperAdminPage({ currentUser, onLogout }: SuperAdminPageProps) {
  const [activeTab, setActiveTab] = useState<'services' | 'system'>('services');
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [autoCallNext, setAutoCallNext] = useState(false);
  const [waitingThreshold, setWaitingThreshold] = useState(15);
  const [resetTime, setResetTime] = useState('00:00');

  return (
    <Layout userRole={currentUser.role} userName={currentUser.name} onLogout={onLogout}>
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">Super Admin</h1>
          <p className="text-gray-600">System configuration and service management</p>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex">
              <button
                onClick={() => setActiveTab('services')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'services'
                    ? 'border-b-2 border-blue-600 text-blue-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  Service Configuration
                </div>
              </button>
              <button
                onClick={() => setActiveTab('system')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'system'
                    ? 'border-b-2 border-blue-600 text-blue-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  System Settings
                </div>
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'services' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Service List</h2>
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                    Add New Service
                  </button>
                </div>

                <div className="space-y-4">
                  {SERVICES.map(service => (
                    <div
                      key={service.id}
                      className="bg-gray-50 rounded-lg p-6 border border-gray-200 hover:border-blue-300 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="inline-flex items-center px-3 py-1 rounded-lg bg-blue-600 text-white text-lg font-bold">
                              {service.code}
                            </span>
                            <h3 className="text-lg font-semibold text-gray-900">{service.name}</h3>
                          </div>
                          
                          <p className="text-sm text-gray-600 mb-3">{service.description}</p>
                          
                          <div className="flex items-center gap-6">
                            <div>
                              <span className="text-xs text-gray-500">Assigned Counters:</span>
                              <div className="flex gap-2 mt-1">
                                {service.counters.map(counter => (
                                  <span
                                    key={counter}
                                    className="inline-flex items-center px-2 py-1 rounded bg-white border border-gray-300 text-sm font-medium text-gray-900"
                                  >
                                    {counter}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                            Edit
                          </button>
                          <button className="px-4 py-2 bg-white border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-colors">
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'system' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">System Configuration</h2>

                <div className="space-y-6">
                  {/* Voice Settings */}
                  <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Volume2 className="w-6 h-6 text-blue-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900">Voice Announcement</h3>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <label className="text-sm font-medium text-gray-900">Enable Voice Calling</label>
                          <p className="text-xs text-gray-600">Play audio announcement when tickets are called</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={voiceEnabled}
                            onChange={(e) => setVoiceEnabled(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-900 mb-2">
                          Voice Language
                        </label>
                        <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                          <option value="en">English</option>
                          <option value="fil">Filipino</option>
                          <option value="zh">Chinese</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-900 mb-2">
                          Voice Volume
                        </label>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          defaultValue="75"
                          className="w-full"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Queue Settings */}
                  <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <Clock className="w-6 h-6 text-green-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900">Queue Settings</h3>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <label className="text-sm font-medium text-gray-900">Auto Call Next Ticket</label>
                          <p className="text-xs text-gray-600">Automatically call next ticket when transaction completes</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={autoCallNext}
                            onChange={(e) => setAutoCallNext(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-900 mb-2">
                          Waiting Time Alert Threshold (minutes)
                        </label>
                        <input
                          type="number"
                          value={waitingThreshold}
                          onChange={(e) => setWaitingThreshold(parseInt(e.target.value))}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                          min="5"
                          max="60"
                        />
                        <p className="text-xs text-gray-600 mt-1">
                          Alert when tickets wait longer than this duration
                        </p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-900 mb-2">
                          Daily Reset Time
                        </label>
                        <input
                          type="time"
                          value={resetTime}
                          onChange={(e) => setResetTime(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        />
                        <p className="text-xs text-gray-600 mt-1">
                          Time when ticket numbers reset daily
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Display Settings */}
                  <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                        <Settings className="w-6 h-6 text-purple-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900">Display Settings</h3>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-900 mb-2">
                          Display Refresh Rate (seconds)
                        </label>
                        <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                          <option value="1">1 second</option>
                          <option value="2">2 seconds</option>
                          <option value="3">3 seconds</option>
                          <option value="5">5 seconds</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-900 mb-2">
                          Show Recently Called (count)
                        </label>
                        <input
                          type="number"
                          defaultValue="5"
                          min="3"
                          max="10"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Save Button */}
                  <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                    <button className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                      Reset to Defaults
                    </button>
                    <button className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                      <Save className="w-5 h-5" />
                      Save Changes
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
