import { useState, useEffect } from 'react';
import { PhoneCall, PhoneForwarded, Pause, CheckCircle, ArrowRightLeft, Volume2 } from 'lucide-react';
import { Layout } from '../components/Layout';
import { KPICard } from '../components/KPICard';
import { TransferModal } from '../components/TransferModal';
import { queueStore, SERVICES } from '../store';
import { Ticket } from '../types';

interface CounterPageProps {
  currentUser: any;
  onLogout: () => void;
}

export function CounterPage({ currentUser, onLogout }: CounterPageProps) {
  const [currentTicket, setCurrentTicket] = useState<Ticket | null>(null);
  const [waitingTickets, setWaitingTickets] = useState<Ticket[]>([]);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [stats, setStats] = useState(queueStore.getStatistics({ userId: currentUser.id }));
  const [, setRefresh] = useState(0);

  const counterNumber = currentUser.assignedCounters[0] || 1;
  const counterServices = SERVICES.filter(s => s.counters.includes(counterNumber));

  useEffect(() => {
    const interval = setInterval(() => {
      updateData();
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const updateData = () => {
    const allWaiting: Ticket[] = [];
    counterServices.forEach(service => {
      const tickets = queueStore.getTickets({ serviceId: service.id, status: 'waiting' });
      allWaiting.push(...tickets);
    });
    setWaitingTickets(allWaiting);
    setStats(queueStore.getStatistics({ userId: currentUser.id }));
    setRefresh(prev => prev + 1);
  };

  const handleCallNext = () => {
    if (waitingTickets.length === 0) return;

    const nextTicket = waitingTickets[0];
    const transaction = queueStore.callTicket(nextTicket.id, counterNumber, currentUser.id);
    setCurrentTicket(nextTicket);
    
    // Simulate voice announcement
    playVoiceAnnouncement(nextTicket.ticketNumber, counterNumber);
    updateData();
  };

  const handleCallAgain = () => {
    if (currentTicket) {
      playVoiceAnnouncement(currentTicket.ticketNumber, counterNumber);
    }
  };

  const handleHold = () => {
    if (currentTicket) {
      queueStore.holdTicket(currentTicket.id);
      setCurrentTicket(null);
      updateData();
    }
  };

  const handleComplete = () => {
    if (currentTicket) {
      queueStore.completeTicket(currentTicket.id);
      setCurrentTicket(null);
      updateData();
    }
  };

  const handleTransfer = (toServiceId?: string, toCounterId?: number, reason?: string) => {
    if (currentTicket) {
      queueStore.transferTicket(currentTicket.id, toServiceId, toCounterId, reason);
      setCurrentTicket(null);
      updateData();
    }
  };

  const playVoiceAnnouncement = (ticketNumber: string, counter: number) => {
    // Simulate voice announcement
    const message = `Now serving ${ticketNumber} at Counter ${counter}`;
    console.log('🔊 Voice Announcement:', message);
    
    // In a real system, this would trigger actual voice synthesis
    alert(`🔊 Voice Announcement:\n\n${message}`);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <Layout userRole={currentUser.role} userName={currentUser.name} onLogout={onLogout}>
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">Counter {counterNumber}</h1>
          <p className="text-gray-600">
            Services: {counterServices.map(s => s.name).join(', ')}
          </p>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <KPICard
            title="In Queue"
            value={waitingTickets.length}
            icon={PhoneCall}
            color="yellow"
          />
          <KPICard
            title="Currently Serving"
            value={currentTicket ? '1' : '0'}
            icon={PhoneForwarded}
            color="green"
          />
          <KPICard
            title="Served Today"
            value={stats.servedToday}
            icon={CheckCircle}
            color="blue"
          />
          <KPICard
            title="Avg Service Time"
            value={formatTime(stats.avgServiceTime)}
            icon={ArrowRightLeft}
            color="purple"
          />
        </div>

        <div className="grid grid-cols-2 gap-6">
          {/* Current Ticket */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Current Ticket</h2>
            
            {currentTicket ? (
              <div>
                <div className="bg-green-50 border-2 border-green-200 rounded-lg p-8 text-center mb-6">
                  <div className="text-6xl font-bold text-green-600 mb-4">
                    {currentTicket.ticketNumber}
                  </div>
                  <div className="text-xl font-medium text-gray-900 mb-2">
                    {currentTicket.client.name}
                  </div>
                  <div className="text-gray-600">
                    {currentTicket.client.profession} • {currentTicket.client.sex}
                  </div>
                  {currentTicket.client.applicationNumber && (
                    <div className="text-sm text-gray-500 mt-2">
                      App #: {currentTicket.client.applicationNumber}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleCallAgain}
                    className="flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Volume2 className="w-5 h-5" />
                    Call Again
                  </button>
                  <button
                    onClick={() => setShowTransferModal(true)}
                    className="flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                  >
                    <ArrowRightLeft className="w-5 h-5" />
                    Transfer
                  </button>
                  <button
                    onClick={handleHold}
                    className="flex items-center justify-center gap-2 px-4 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors"
                  >
                    <Pause className="w-5 h-5" />
                    Hold
                  </button>
                  <button
                    onClick={handleComplete}
                    className="flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <CheckCircle className="w-5 h-5" />
                    Complete
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <PhoneCall className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-500 mb-6">No ticket being served</p>
                <button
                  onClick={handleCallNext}
                  disabled={waitingTickets.length === 0}
                  className="px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-lg disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Call Next Ticket
                </button>
              </div>
            )}
          </div>

          {/* Waiting Queue */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Waiting Queue ({waitingTickets.length})
            </h2>
            
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {waitingTickets.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  No tickets in queue
                </div>
              ) : (
                waitingTickets.map((ticket, index) => {
                  const service = SERVICES.find(s => s.id === ticket.serviceId);
                  const waitTime = Math.floor((Date.now() - ticket.createdAt.getTime()) / 1000 / 60);
                  
                  return (
                    <div
                      key={ticket.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-blue-600 font-semibold">{index + 1}</span>
                        </div>
                        <div>
                          <div className="text-lg font-semibold text-gray-900">{ticket.ticketNumber}</div>
                          <div className="text-sm text-gray-600">{ticket.client.name}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">{service?.name}</div>
                        <div className="text-xs text-gray-500">Waiting: {waitTime} min</div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      <TransferModal
        isOpen={showTransferModal}
        onClose={() => setShowTransferModal(false)}
        onTransfer={handleTransfer}
        currentServiceId={currentTicket?.serviceId || ''}
        currentCounterId={counterNumber}
      />
    </Layout>
  );
}
