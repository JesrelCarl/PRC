import { useState, useEffect } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Calendar, TrendingUp, Clock, Users, CheckCircle, AlertCircle } from 'lucide-react';
import { Layout } from '../components/Layout';
import { KPICard } from '../components/KPICard';
import { queueStore, SERVICES } from '../store';

interface AnalyticsPageProps {
  currentUser: any;
  onLogout: () => void;
}

export function AnalyticsPage({ currentUser, onLogout }: AnalyticsPageProps) {
  const [stats, setStats] = useState(queueStore.getStatistics());
  const [filter, setFilter] = useState({
    serviceId: '',
    dateRange: 'today'
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(queueStore.getStatistics());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Service distribution data
  const serviceData = SERVICES.map(service => {
    const tickets = queueStore.getTickets({ serviceId: service.id });
    return {
      name: service.name,
      code: service.code,
      total: tickets.length,
      waiting: tickets.filter(t => t.status === 'waiting').length,
      serving: tickets.filter(t => t.status === 'serving').length,
      completed: tickets.filter(t => t.status === 'completed').length
    };
  });

  // Hourly distribution (mock data for demo)
  const hourlyData = Array.from({ length: 12 }, (_, i) => {
    const hour = i + 8; // 8 AM to 7 PM
    return {
      hour: `${hour}:00`,
      tickets: Math.floor(Math.random() * 20) + 5
    };
  });

  // Service time distribution
  const serviceTimeData = SERVICES.slice(0, 5).map(service => ({
    name: service.code,
    avgTime: Math.floor(Math.random() * 10) + 3
  }));

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4'];

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <Layout userRole={currentUser.role} userName={currentUser.name} onLogout={onLogout}>
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">Analytics Dashboard</h1>
          <p className="text-gray-600">Real-time queue performance and statistics</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Service Filter
              </label>
              <select
                value={filter.serviceId}
                onChange={(e) => setFilter({ ...filter, serviceId: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Services</option>
                {SERVICES.map(service => (
                  <option key={service.id} value={service.id}>
                    {service.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date Range
              </label>
              <select
                value={filter.dateRange}
                onChange={(e) => setFilter({ ...filter, dateRange: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="today">Today</option>
                <option value="week">This Week</option>
                <option value="month">This Month</option>
              </select>
            </div>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <KPICard
            title="Total In Queue"
            value={stats.inQueue}
            icon={Users}
            color="yellow"
          />
          <KPICard
            title="Currently Serving"
            value={stats.serving}
            icon={TrendingUp}
            color="green"
          />
          <KPICard
            title="Served Today"
            value={stats.servedToday}
            icon={CheckCircle}
            color="blue"
          />
          <KPICard
            title="Avg Waiting Time"
            value={formatTime(stats.avgWaitingTime)}
            icon={Clock}
            color="purple"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          {/* Service Distribution */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Service Distribution</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={serviceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="code" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="waiting" fill="#F59E0B" name="Waiting" />
                <Bar dataKey="serving" fill="#10B981" name="Serving" />
                <Bar dataKey="completed" fill="#3B82F6" name="Completed" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Hourly Trend */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Hourly Ticket Trend</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={hourlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="tickets" stroke="#3B82F6" strokeWidth={2} name="Tickets" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6">
          {/* Service Breakdown */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Service Breakdown</h2>
            <div className="space-y-3">
              {serviceData.map((service, index) => (
                <div key={service.code} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-4 h-4 rounded"
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <div>
                      <div className="font-medium text-gray-900">{service.name}</div>
                      <div className="text-sm text-gray-600">Code: {service.code}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-semibold text-gray-900">{service.total}</div>
                    <div className="text-sm text-gray-600">tickets</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Average Service Time */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Average Service Time by Service</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={serviceTimeData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" />
                <Tooltip />
                <Bar dataKey="avgTime" fill="#8B5CF6" name="Avg Time (min)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="mt-6 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Performance Metrics</h2>
          <div className="grid grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">{stats.totalTransactions}</div>
              <div className="text-sm text-gray-600 mt-1">Total Transactions</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{formatTime(stats.avgServiceTime)}</div>
              <div className="text-sm text-gray-600 mt-1">Avg Service Time</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">{formatTime(stats.avgWaitingTime)}</div>
              <div className="text-sm text-gray-600 mt-1">Avg Waiting Time</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600">
                {stats.servedToday > 0 ? Math.round((stats.servedToday / (stats.servedToday + stats.inQueue)) * 100) : 0}%
              </div>
              <div className="text-sm text-gray-600 mt-1">Completion Rate</div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
