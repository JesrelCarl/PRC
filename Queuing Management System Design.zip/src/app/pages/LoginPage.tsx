import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ClipboardList } from 'lucide-react';
import { USERS } from '../store';

interface LoginPageProps {
  onLogin: (userId: string) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const user = USERS.find(u => u.username === username);
    
    if (!user) {
      setError('Invalid username or password');
      return;
    }

    // In a real app, verify password here
    onLogin(user.id);

    // Navigate based on role
    switch (user.role) {
      case 'frontdesk':
        navigate('/frontdesk');
        break;
      case 'counter':
        navigate('/counter');
        break;
      case 'admin':
        navigate('/admin');
        break;
      case 'super-admin':
        navigate('/super-admin');
        break;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="inline-flex w-16 h-16 rounded-2xl bg-blue-600 items-center justify-center mb-4">
            <ClipboardList className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl font-semibold text-gray-900 mb-2">
            Queue Management System
          </h1>
          <p className="text-gray-600">Sign in to continue</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-800 text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Username
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter your username"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter your password"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Sign In
          </button>
        </form>

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <p className="text-xs text-gray-600 font-medium mb-2">Demo Accounts:</p>
          <div className="space-y-1 text-xs text-gray-600">
            <div>• Frontdesk: <code className="bg-white px-1 py-0.5 rounded">frontdesk</code></div>
            <div>• Counter: <code className="bg-white px-1 py-0.5 rounded">counter1</code></div>
            <div>• Admin: <code className="bg-white px-1 py-0.5 rounded">admin</code></div>
            <div>• Super Admin: <code className="bg-white px-1 py-0.5 rounded">superadmin</code></div>
          </div>
        </div>
      </div>
    </div>
  );
}
