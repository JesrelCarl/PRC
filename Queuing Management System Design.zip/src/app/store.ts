// Mock data store and state management for the Queuing Management System

import { Service, Counter, User, Ticket, Transaction, ServiceCode, TicketStatus } from './types';

// Services Configuration
export const SERVICES: Service[] = [
  {
    id: 'application',
    name: 'Application',
    code: 'E',
    counters: [1, 2, 3, 4, 5, 6, 7],
    description: 'Application services'
  },
  {
    id: 'records',
    name: 'Records',
    code: 'C',
    counters: [8, 9, 10],
    description: 'Records request'
  },
  {
    id: 'renewal',
    name: 'Registration - Renewal',
    code: 'R',
    counters: [13],
    description: 'Registration renewal'
  },
  {
    id: 'good-standing',
    name: 'Registration - Good Standing / Auth of PIC',
    code: 'G',
    counters: [14],
    description: 'Good standing and authentication'
  },
  {
    id: 'initial',
    name: 'Registration - Initial / New',
    code: 'I',
    counters: [15],
    description: 'Initial registration'
  },
  {
    id: 'regulation',
    name: 'Regulation',
    code: 'S',
    counters: [16, 17, 18, 19, 20, 21],
    description: 'Regulation services'
  },
  {
    id: 'ord-legal',
    name: 'ORD-Legal',
    code: 'L',
    counters: [22],
    description: 'Legal office services'
  }
];

// Counters Configuration
export const COUNTERS: Counter[] = [
  ...Array.from({ length: 22 }, (_, i) => {
    const counterNum = i + 1;
    const service = SERVICES.find(s => s.counters.includes(counterNum));
    return {
      id: counterNum,
      name: `Counter ${counterNum}`,
      serviceIds: service ? [service.id] : [],
      isActive: true
    };
  })
];

// Mock Users
export const USERS: User[] = [
  {
    id: 'frontdesk-1',
    username: 'frontdesk',
    name: 'Maria Santos',
    role: 'frontdesk',
    assignedCounters: [],
    isActive: true
  },
  {
    id: 'counter-1',
    username: 'counter1',
    name: 'Juan Dela Cruz',
    role: 'counter',
    assignedCounters: [1],
    isActive: true
  },
  {
    id: 'counter-2',
    username: 'counter2',
    name: 'Ana Reyes',
    role: 'counter',
    assignedCounters: [2],
    isActive: true
  },
  {
    id: 'admin-1',
    username: 'admin',
    name: 'Admin User',
    role: 'admin',
    assignedCounters: [],
    isActive: true
  },
  {
    id: 'superadmin-1',
    username: 'superadmin',
    name: 'Super Admin',
    role: 'super-admin',
    assignedCounters: [],
    isActive: true
  }
];

// State Management Class
class QueueStore {
  private tickets: Ticket[] = [];
  private transactions: Transaction[] = [];
  private sequenceCounters: Record<ServiceCode, number> = {
    E: 0, C: 0, R: 0, G: 0, I: 0, S: 0, L: 0
  };
  private lastResetDate: string = new Date().toDateString();

  constructor() {
    this.checkDailyReset();
    this.initializeMockData();
  }

  private checkDailyReset() {
    const today = new Date().toDateString();
    if (this.lastResetDate !== today) {
      this.resetDailyCounters();
      this.lastResetDate = today;
    }
  }

  private resetDailyCounters() {
    this.sequenceCounters = { E: 0, C: 0, R: 0, G: 0, I: 0, S: 0, L: 0 };
    this.tickets = [];
    this.transactions = [];
  }

  private initializeMockData() {
    // Generate some mock tickets for demo
    const mockClients = [
      { name: 'John Doe', profession: 'Engineer', sex: 'Male' as const },
      { name: 'Jane Smith', profession: 'Nurse', sex: 'Female' as const },
      { name: 'Robert Garcia', profession: 'Teacher', sex: 'Male' as const },
      { name: 'Lisa Wong', profession: 'Accountant', sex: 'Female' as const },
      { name: 'Michael Cruz', profession: 'Architect', sex: 'Male' as const }
    ];

    // Create some sample tickets
    const services = ['application', 'records', 'renewal'];
    mockClients.forEach((client, idx) => {
      const serviceId = services[idx % services.length];
      const service = SERVICES.find(s => s.id === serviceId)!;
      this.generateTicket(serviceId, client, 1);
      
      // Some tickets should be serving or completed
      if (idx < 2) {
        const ticket = this.tickets[this.tickets.length - 1];
        ticket.status = 'serving';
        ticket.calledAt = new Date(Date.now() - 5 * 60 * 1000); // 5 mins ago
        ticket.counterId = service.counters[0];
        
        this.transactions.push({
          id: `tx-${ticket.id}`,
          ticketId: ticket.id,
          ticketNumber: ticket.ticketNumber,
          serviceId: ticket.serviceId,
          counterId: ticket.counterId,
          userId: 'counter-1',
          client: ticket.client,
          startTime: ticket.calledAt,
          waitingTime: Math.floor((ticket.calledAt.getTime() - ticket.createdAt.getTime()) / 1000),
          status: 'in-progress'
        });
      }
    });
  }

  generateTicket(serviceId: string, client: any, quantity: number = 1): Ticket {
    this.checkDailyReset();
    
    const service = SERVICES.find(s => s.id === serviceId);
    if (!service) throw new Error('Service not found');

    this.sequenceCounters[service.code]++;
    const sequence = this.sequenceCounters[service.code];
    const ticketNumber = `${service.code}-${String(sequence).padStart(3, '0')}`;

    const ticket: Ticket = {
      id: `ticket-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ticketNumber,
      serviceId: service.id,
      serviceCode: service.code,
      sequence,
      client,
      quantity,
      status: 'waiting',
      createdAt: new Date()
    };

    this.tickets.push(ticket);
    return ticket;
  }

  getTickets(filter?: { serviceId?: string; status?: TicketStatus; counterId?: number }): Ticket[] {
    let filtered = [...this.tickets];
    
    if (filter?.serviceId) {
      filtered = filtered.filter(t => t.serviceId === filter.serviceId);
    }
    if (filter?.status) {
      filtered = filtered.filter(t => t.status === filter.status);
    }
    if (filter?.counterId) {
      filtered = filtered.filter(t => t.counterId === filter.counterId);
    }

    return filtered.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  getNextTicket(serviceId: string): Ticket | null {
    const waiting = this.getTickets({ serviceId, status: 'waiting' });
    return waiting[0] || null;
  }

  callTicket(ticketId: string, counterId: number, userId: string): Transaction {
    const ticket = this.tickets.find(t => t.id === ticketId);
    if (!ticket) throw new Error('Ticket not found');

    ticket.status = 'serving';
    ticket.calledAt = new Date();
    ticket.counterId = counterId;
    ticket.assignedUserId = userId;

    const waitingTime = Math.floor((ticket.calledAt.getTime() - ticket.createdAt.getTime()) / 1000);

    const transaction: Transaction = {
      id: `tx-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ticketId: ticket.id,
      ticketNumber: ticket.ticketNumber,
      serviceId: ticket.serviceId,
      counterId,
      userId,
      client: ticket.client,
      startTime: ticket.calledAt,
      waitingTime,
      status: 'in-progress'
    };

    this.transactions.push(transaction);
    return transaction;
  }

  completeTicket(ticketId: string): void {
    const ticket = this.tickets.find(t => t.id === ticketId);
    const transaction = this.transactions.find(t => t.ticketId === ticketId && t.status === 'in-progress');

    if (ticket) {
      ticket.status = 'completed';
      ticket.completedAt = new Date();
    }

    if (transaction) {
      transaction.endTime = new Date();
      transaction.serviceTime = Math.floor((transaction.endTime.getTime() - transaction.startTime.getTime()) / 1000);
      transaction.status = 'completed';
    }
  }

  transferTicket(ticketId: string, toServiceId?: string, toCounterId?: number, reason?: string): void {
    const ticket = this.tickets.find(t => t.id === ticketId);
    if (!ticket) return;

    const transferRecord = {
      fromService: toServiceId ? ticket.serviceId : undefined,
      toService: toServiceId,
      fromCounter: toCounterId ? ticket.counterId : undefined,
      toCounter: toCounterId,
      reason: reason || 'Transfer',
      transferredAt: new Date(),
      transferredBy: 'current-user'
    };

    if (!ticket.transferHistory) {
      ticket.transferHistory = [];
    }
    ticket.transferHistory.push(transferRecord);

    if (toServiceId) {
      const newService = SERVICES.find(s => s.id === toServiceId);
      if (newService) {
        ticket.serviceId = toServiceId;
        ticket.serviceCode = newService.code;
      }
    }

    if (toCounterId) {
      ticket.counterId = toCounterId;
    }

    ticket.status = 'waiting';
  }

  holdTicket(ticketId: string): void {
    const ticket = this.tickets.find(t => t.id === ticketId);
    if (ticket) {
      ticket.status = 'on-hold';
    }
  }

  getTransactions(filter?: { userId?: string; date?: Date }): Transaction[] {
    let filtered = [...this.transactions];
    
    if (filter?.userId) {
      filtered = filtered.filter(t => t.userId === filter.userId);
    }

    return filtered;
  }

  getStatistics(filter?: { serviceId?: string; userId?: string; date?: Date }) {
    const tickets = this.getTickets(filter);
    const transactions = this.getTransactions(filter);

    const completed = transactions.filter(t => t.status === 'completed');
    
    const avgWaitingTime = completed.length > 0
      ? completed.reduce((sum, t) => sum + t.waitingTime, 0) / completed.length
      : 0;

    const avgServiceTime = completed.filter(t => t.serviceTime).length > 0
      ? completed.filter(t => t.serviceTime).reduce((sum, t) => sum + (t.serviceTime || 0), 0) / completed.filter(t => t.serviceTime).length
      : 0;

    return {
      inQueue: tickets.filter(t => t.status === 'waiting').length,
      serving: tickets.filter(t => t.status === 'serving').length,
      servedToday: completed.length,
      avgWaitingTime: Math.floor(avgWaitingTime),
      avgServiceTime: Math.floor(avgServiceTime),
      totalTransactions: transactions.length
    };
  }

  getCurrentlyServing(): Ticket[] {
    return this.tickets.filter(t => t.status === 'serving');
  }

  getRecentlyCalled(limit: number = 5): Ticket[] {
    return this.tickets
      .filter(t => t.calledAt)
      .sort((a, b) => (b.calledAt?.getTime() || 0) - (a.calledAt?.getTime() || 0))
      .slice(0, limit);
  }
}

export const queueStore = new QueueStore();
