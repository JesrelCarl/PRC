import { Ticket } from '../types';
import { SERVICES } from '../store';

interface PrintTicketProps {
  tickets: Ticket[];
}

export function PrintTicket({ tickets }: PrintTicketProps) {
  return (
    <div className="hidden print:block">
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print-container, .print-container * {
            visibility: visible;
          }
          .print-container {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          .ticket-print {
            page-break-after: always;
            padding: 40px;
            text-align: center;
          }
          .ticket-print:last-child {
            page-break-after: auto;
          }
        }
      `}</style>
      <div className="print-container">
        {tickets.map(ticket => {
          const service = SERVICES.find(s => s.id === ticket.serviceId);
          return (
            <div key={ticket.id} className="ticket-print">
              <h1 style={{ fontSize: '24px', marginBottom: '20px' }}>
                Queue Management System
              </h1>
              <div style={{ fontSize: '72px', fontWeight: 'bold', margin: '40px 0', color: '#2563eb' }}>
                {ticket.ticketNumber}
              </div>
              <div style={{ fontSize: '24px', marginBottom: '10px' }}>
                {service?.name}
              </div>
              <div style={{ fontSize: '18px', marginBottom: '20px', color: '#6b7280' }}>
                Counters: {service?.counters.join(', ')}
              </div>
              <div style={{ fontSize: '16px', marginTop: '40px', color: '#6b7280' }}>
                {ticket.client.name}
              </div>
              {ticket.client.applicationNumber && (
                <div style={{ fontSize: '14px', color: '#9ca3af' }}>
                  Application #: {ticket.client.applicationNumber}
                </div>
              )}
              <div style={{ fontSize: '12px', marginTop: '40px', color: '#9ca3af' }}>
                {new Date(ticket.createdAt).toLocaleString()}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
