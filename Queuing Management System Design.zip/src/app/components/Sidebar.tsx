import { Link, useLocation } from 'react-router';
import { 
  LayoutDashboard, 
  Users, 
  Monitor, 
  BarChart3, 
  Settings, 
  UserCog, 
  ClipboardList,
  TrendingUp,
  LogOut
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  userRole: UserRole;
  userName: string;
  onLogout: () => void;
}

export function Sidebar({ userRole, userName, onLogout }: SidebarProps) {
  const location = useLocation();

  const getNavItems = () => {
    switch (userRole) {
      case 'frontdesk':
        return [
          { path: '/frontdesk', label: 'Frontdesk', icon: ClipboardList },
          { path: '/display', label: 'Display View', icon: Monitor }
        ];
      case 'counter':
        return [
          { path: '/counter', label: 'Counter Dashboard', icon: LayoutDashboard },
          { path: '/analytics', label: 'My Analytics', icon: BarChart3 },
          { path: '/display', label: 'Display View', icon: Monitor }
        ];
      case 'admin':
        return [
          { path: '/admin', label: 'Admin Panel', icon: UserCog },
          { path: '/analytics', label: 'Analytics', icon: BarChart3 },
          { path: '/executive', label: 'Executive Dashboard', icon: TrendingUp },
          { path: '/display', label: 'Display View', icon: Monitor }
        ];
      case 'super-admin':
        return [
          { path: '/super-admin', label: 'Super Admin', icon: Settings },
          { path: '/admin', label: 'Admin Panel', icon: UserCog },
          { path: '/analytics', label: 'Analytics', icon: BarChart3 },
          { path: '/executive', label: 'Executive Dashboard', icon: TrendingUp },
          { path: '/display', label: 'Display View', icon: Monitor }
        ];
      default:
        return [];
    }
  };

  const navItems = getNavItems();

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col h-screen">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center">
            <ClipboardList className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-semibold text-gray-900">QMS</h1>
            <p className="text-xs text-gray-500">Queue Management</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-200">
        <div className="px-4 py-3 mb-2 rounded-lg bg-gray-50">
          <p className="text-sm font-medium text-gray-900">{userName}</p>
          <p className="text-xs text-gray-500 capitalize">{userRole.replace('-', ' ')}</p>
        </div>
        <button
          onClick={onLogout}
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 w-full transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
}
