import { ReactNode } from 'react';
import { Sidebar } from './Sidebar';
import { UserRole } from '../types';

interface LayoutProps {
  children: ReactNode;
  userRole: UserRole;
  userName: string;
  onLogout: () => void;
}

export function Layout({ children, userRole, userName, onLogout }: LayoutProps) {
  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar userRole={userRole} userName={userName} onLogout={onLogout} />
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}
