import { Ticket } from '../types';
import { Clock, User } from 'lucide-react';

interface TicketCardProps {
  ticket: Ticket;
  onCall?: () => void;
  showActions?: boolean;
}

export function TicketCard({ ticket, onCall, showActions = false }: TicketCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'waiting': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'serving': return 'bg-green-100 text-green-800 border-green-200';
      case 'completed': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'on-hold': return 'bg-red-100 text-red-800 border-red-200';
      case 'transferred': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getWaitingTime = () => {
    const now = new Date().getTime();
    const created = ticket.createdAt.getTime();
    const diff = Math.floor((now - created) / 1000 / 60);
    return `${diff} min${diff !== 1 ? 's' : ''}`;
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="text-2xl font-semibold text-gray-900">{ticket.ticketNumber}</h3>
          <p className="text-sm text-gray-600 mt-1">{ticket.client.name}</p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(ticket.status)}`}>
          {ticket.status.replace('-', ' ')}
        </span>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <User className="w-4 h-4" />
          <span>{ticket.client.profession}</span>
        </div>
        {ticket.status === 'waiting' && (
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Clock className="w-4 h-4" />
            <span>Waiting: {getWaitingTime()}</span>
          </div>
        )}
        {ticket.counterId && (
          <div className="text-sm text-gray-600">
            Counter: <span className="font-medium">{ticket.counterId}</span>
          </div>
        )}
        {ticket.quantity > 1 && (
          <div className="text-sm text-gray-600">
            Quantity: <span className="font-medium">{ticket.quantity}</span>
          </div>
        )}
      </div>

      {showActions && onCall && ticket.status === 'waiting' && (
        <button
          onClick={onCall}
          className="w-full mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          Call Ticket
        </button>
      )}
    </div>
  );
}
