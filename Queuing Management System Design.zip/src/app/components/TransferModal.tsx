import { useState } from 'react';
import { X } from 'lucide-react';
import { SERVICES, COUNTERS } from '../store';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTransfer: (toServiceId?: string, toCounterId?: number, reason?: string) => void;
  currentServiceId: string;
  currentCounterId?: number;
}

export function TransferModal({ 
  isOpen, 
  onClose, 
  onTransfer, 
  currentServiceId,
  currentCounterId 
}: TransferModalProps) {
  const [transferType, setTransferType] = useState<'service' | 'counter'>('service');
  const [toServiceId, setToServiceId] = useState('');
  const [toCounterId, setToCounterId] = useState('');
  const [reason, setReason] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (transferType === 'service' && toServiceId) {
      onTransfer(toServiceId, undefined, reason);
    } else if (transferType === 'counter' && toCounterId) {
      onTransfer(undefined, parseInt(toCounterId), reason);
    }
    
    onClose();
    setToServiceId('');
    setToCounterId('');
    setReason('');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Transfer Ticket</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Transfer Type
            </label>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="service"
                  checked={transferType === 'service'}
                  onChange={(e) => setTransferType(e.target.value as 'service' | 'counter')}
                  className="mr-2"
                />
                <span className="text-sm text-gray-700">To Another Service</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="counter"
                  checked={transferType === 'counter'}
                  onChange={(e) => setTransferType(e.target.value as 'service' | 'counter')}
                  className="mr-2"
                />
                <span className="text-sm text-gray-700">To Another Counter</span>
              </label>
            </div>
          </div>

          {transferType === 'service' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Service
              </label>
              <select
                value={toServiceId}
                onChange={(e) => setToServiceId(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">Select a service...</option>
                {SERVICES.filter(s => s.id !== currentServiceId).map(service => (
                  <option key={service.id} value={service.id}>
                    {service.name} ({service.code})
                  </option>
                ))}
              </select>
            </div>
          )}

          {transferType === 'counter' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Counter
              </label>
              <select
                value={toCounterId}
                onChange={(e) => setToCounterId(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">Select a counter...</option>
                {COUNTERS.filter(c => c.id !== currentCounterId).map(counter => (
                  <option key={counter.id} value={counter.id}>
                    Counter {counter.id}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Reason for Transfer
            </label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="">Select reason...</option>
              <option value="Wrong Service Selected">Wrong Service Selected</option>
              <option value="Requires Different Service">Requires Different Service</option>
              <option value="Counter Unavailable">Counter Unavailable</option>
              <option value="Staff Request">Staff Request</option>
              <option value="Client Request">Client Request</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              Transfer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
