
  # Queuing Management System Design

  This is a code bundle for Queuing Management System Design. The original project is available at https://www.figma.com/design/dAFzzXuZE0c2D8qiwuyI29/Queuing-Management-System-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  