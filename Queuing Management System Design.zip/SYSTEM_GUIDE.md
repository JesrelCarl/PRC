# Queue Management System - User Guide

## System Overview
A comprehensive web-based queuing management system designed for government/service offices with walk-in clients.

## Demo Accounts

### Login Credentials
- **Frontdesk**: `frontdesk` / any password
- **Counter Staff**: `counter1` / any password
- **Admin**: `admin` / any password
- **Super Admin**: `superadmin` / any password

## Service Configuration

### Services & Counters
1. **Application (E)** - Counters: 1-7
2. **Records (C)** - Counters: 8-10
3. **Registration - Renewal (R)** - Counter: 13
4. **Registration - Good Standing (G)** - Counter: 14
5. **Registration - Initial (I)** - Counter: 15
6. **Regulation (S)** - Counters: 16-21
7. **ORD-Legal (L)** - Counter: 22

## System Features

### 1. Frontdesk / PACD Module
**Access**: Frontdesk staff only

**Features**:
- Client information entry (Name, Profession, Sex, Application Number)
- Multiple service selection per client
- Quantity selection per service
- Automatic ticket generation with unique codes
- Print ticket functionality
- Real-time ticket display

**How to Use**:
1. Enter client information
2. Click "Add Service" to select services
3. Choose service(s) and quantity
4. Click "Generate Tickets"
5. Print or proceed to next client

### 2. Counter User Module
**Access**: Counter staff only

**Features**:
- Call next ticket in queue
- Re-announce ticket (voice simulation)
- Hold ticket temporarily
- Transfer ticket to another service/counter
- Complete transaction
- Real-time queue monitoring
- Performance statistics

**How to Use**:
1. Click "Call Next Ticket" to serve first in queue
2. Use "Call Again" to re-announce
3. Use "Transfer" to move ticket to another service/counter
4. Use "Hold" to pause service
5. Click "Complete" when transaction is finished

### 3. Analytics Dashboard
**Access**: Counter staff, Admin, Super Admin

**Features**:
- Real-time KPI cards (In Queue, Serving, Served, Avg Times)
- Service distribution charts
- Hourly trend analysis
- Service breakdown statistics
- Average service time by service
- Performance metrics

**Filters**:
- Service filter
- Date range (Today, This Week, This Month)

### 4. Executive Dashboard
**Access**: Admin, Super Admin

**Features**:
- High-level KPI cards with gradient design
- Peak hour analysis chart
- Service performance comparison
- Detailed service overview table
- Overall system statistics
- Real-time monitoring

**Key Metrics**:
- Total in queue across all services
- Total served today
- Average waiting time
- Currently serving
- Most requested service
- Longest waiting ticket

### 5. Admin Panel
**Access**: Admin, Super Admin

**Features**:
- User management (Add, Edit, Delete users)
- Assign counters to users
- Role assignment
- User status management
- Report generation

**Report Types**:
- Daily Transaction Report
- Service Performance Report
- User Activity Report
- Monthly Summary

### 6. Super Admin Panel
**Access**: Super Admin only

**Features**:
- Service configuration (Add, Edit, Delete services)
- Counter assignment per service
- System settings:
  - Voice announcement settings
  - Auto-call next ticket
  - Waiting time alert threshold
  - Daily reset time
  - Display refresh rate

### 7. Display / TV View
**Access**: Public (no login required)

**Features**:
- Full-screen public display
- Currently serving tickets (large display)
- Recently called tickets (last 5)
- Queue status per service
- Real-time clock and date
- Announcements section
- Auto-refresh every 2 seconds

**URL**: Navigate to `/display` (no authentication needed)

## Key Workflows

### Walk-in Client Flow
1. Client arrives at frontdesk
2. Frontdesk generates ticket(s) based on service(s) needed
3. Client receives printed ticket with number and counter assignment
4. Client waits in waiting area (views TV display)
5. Counter staff calls ticket (voice announcement)
6. Client proceeds to assigned counter
7. Staff serves client
8. Staff completes transaction
9. System logs all times and statistics

### Ticket Transfer Flow
1. Counter staff identifies need for transfer
2. Click "Transfer" button
3. Select transfer type (service or counter)
4. Choose destination
5. Select reason for transfer
6. Confirm transfer
7. Ticket returns to queue with updated assignment

### Analytics Review Flow
1. Login with appropriate role
2. Navigate to Analytics or Executive dashboard
3. Apply filters (service, date range)
4. Review charts and metrics
5. Export reports (Admin only)

## System Behavior

### Daily Reset
- Ticket numbers reset at midnight (configurable)
- Format: [SERVICE_CODE]-[SEQUENCE]
- Example: E-001, C-015, R-003

### Time Tracking
1. **Waiting Time**: Ticket creation → Call time
2. **Service Time**: Call time → Complete time
3. **Total Time**: Sum of all service times for client

### Status Colors
- **Yellow**: Waiting
- **Green**: Serving
- **Gray**: Completed
- **Red**: On Hold/Delayed
- **Blue**: Transferred

### Voice Announcements
When a ticket is called, system simulates voice announcement:
"Now serving [TICKET_NUMBER] at Counter [NUMBER]"

## Tips for Best Use

### For Frontdesk
- Always verify client information before generating tickets
- Select all required services at once to avoid multiple tickets
- Use print function for physical tickets

### For Counter Staff
- Keep queue moving by promptly completing transactions
- Use "Hold" for clients who need additional documents
- Transfer tickets appropriately when service mismatch occurs
- Call tickets again if client doesn't respond immediately

### For Admins
- Regularly review analytics to identify bottlenecks
- Monitor peak hours and adjust counter assignments
- Generate reports for management review
- Manage user access and counter assignments

### For Super Admins
- Configure services based on office requirements
- Adjust waiting time thresholds to alert for long waits
- Fine-tune voice and display settings
- Monitor overall system performance

## Technical Notes

### Real-time Updates
- Display view auto-refreshes every 2 seconds
- Counter dashboard updates every 2 seconds
- All statistics calculate in real-time

### Browser Compatibility
- Works on all modern browsers (Chrome, Firefox, Safari, Edge)
- Display view optimized for large screens/TVs
- Responsive design for desktop use

### Printing
- Ticket print layout optimized for thermal/receipt printers
- Each ticket prints on separate page
- Includes QR code capability (future enhancement)

## Support & Troubleshooting

### Common Issues
1. **Ticket not appearing in queue**: Refresh the page
2. **Voice not playing**: Check browser audio permissions
3. **Print not working**: Check printer connection and browser print settings
4. **Display not updating**: Check internet connection and refresh

### Best Practices
- Keep browser tabs open for real-time updates
- Use dedicated computer/tablet for display view
- Regular backup of statistics and reports
- Train staff on all features before deployment

---

**System Version**: 1.0  
**Last Updated**: March 2026
